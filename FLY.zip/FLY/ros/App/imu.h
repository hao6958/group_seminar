#ifndef __IMU_H__
#define __IMU_H__

#include <stdint.h>

void Imu_Init(void);
void Imu_Attiude(void);
float* Imu_GetOular(void);

#endif
