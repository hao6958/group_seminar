#ifndef _TASKS_H_
#define	_TASKS_H_
#include "stm32f10x.h"
#include "struct_all.h"
#include <stdint.h>

extern uint32_t runtime;

void System_Init(void);
void delay_ms(uint16_t msec);
uint32_t System_GetTime(void);

/******************************************************************************
							ȫ�ֱ�������
*******************************************************************************/ 
extern uint8_t Bsp_Int_Ok; 

/******************************************************************************
							ȫ�ֺ�������
*******************************************************************************/ 
void BSP_Init(void);
void Task_500HZ(void);
void Task_100HZ(void);
void Task_25HZ(void);
void Task_4HZ(void);
void Task_Init(void);

#endif
