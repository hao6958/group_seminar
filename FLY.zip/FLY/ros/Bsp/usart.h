#ifndef __USART3_H__
#define __USART3_H__

#include <stdint.h>

void Usart_Configuration(void);
void Usart_Send(uint8_t data);
char Usart_DataAvailable();
uint8_t Usart_Getch();
char Usart_FreeSpace();
char Usart_Putch(uint8_t data);
void PrintHexU8(uint8_t data);
void Usart_Sendl(uint8_t *s ,uint8_t len);



#endif
