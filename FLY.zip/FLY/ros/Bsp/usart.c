#include "includes.h"
#include "usart.h"
#include "Tasks.h"

const static int UART_BUFSIZE = 512;
/* @brief Receive buffer. */
volatile uint8_t RX[UART_BUFSIZE];
volatile uint8_t TX[UART_BUFSIZE];
/* @brief Receive buffer head. */
volatile uint16_t RX_Head=0;
/* @brief Receive buffer tail. */
volatile uint16_t RX_Tail=0;
/* @brief Transmit buffer head. */
volatile uint16_t TX_Head=0;
/* @brief Transmit buffer tail. */
volatile uint16_t TX_Tail=0;
static uint8_t Count=0;

// ��������
static void Usart_GpioConfig(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	/* ��GPIO��USART������ʱ�� */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	/* ��USART Tx��GPIO����Ϊ���츴��ģʽ */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	/* ��USART Rx��GPIO����Ϊ��������ģʽ */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);      
}

// ģʽ����
static void Usart_ModeConfig(void)
{
    USART_InitTypeDef USART_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

	  USART_InitStructure.USART_BaudRate = 57600;//������
	  USART_InitStructure.USART_WordLength = USART_WordLength_8b;//��λ����λ
	  USART_InitStructure.USART_StopBits = USART_StopBits_1;//һλֹͣλ
	  USART_InitStructure.USART_Parity = USART_Parity_No;//��������żУ��
	  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//Ӳ��������ʧ��
		USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;//����+����ģʽ
		USART_Init(USART1, &USART_InitStructure);
		/* ʹ�ܴ��ڽ����ж� */
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
		/* ��5����ʹ�� USART�� ������� */
		USART_Cmd(USART1, ENABLE);
		/* CPU��Сȱ�ݣ��������úã����ֱ��Send�����1���ֽڷ��Ͳ���ȥ
		�����������1���ֽ��޷���ȷ���ͳ�ȥ������ */
		USART_ClearFlag(USART1, USART_FLAG_TC);//�巢����ɱ�־λ
}

// Usart3��ʼ��
void Usart_Configuration(void)
{
    Usart_GpioConfig();
    Usart_ModeConfig();
}

void Usart_Send(uint8_t data)
{
	//while (!(USART1->SR & USART_FLAG_TXE));
	while( USART_GetFlagStatus(USART1,USART_FLAG_TC)!= SET);
	/* ��Printf���ݷ������� */
	USART_SendData(USART1, (unsigned char)data);// 
}

void PrintHexU8(uint8_t data)
{
	TX[Count++] = data;  
	if(!(USART1->CR1 & USART_CR1_TXEIE))
		USART_ITConfig(USART1, USART_IT_TXE, ENABLE); //��TXE�ж�
}
void Usart_Sendl(uint8_t *s ,uint8_t len)
{
	while(len)
	{
		Usart_Send(*s);
		s++;
		len--;
	}
}

char Usart_FreeSpace(void)
{
    uint16_t tempHead = (TX_Head + 1) % (UART_BUFSIZE-1);
    uint16_t tempTail = TX_Tail;
    return (tempHead != tempTail);
}

char Usart_Putch(uint8_t data)
{
    uint16_t tempTX_Head;
    bool isFree = Usart_FreeSpace();

    if(isFree)
    {
        tempTX_Head = TX_Head;

        USART_ITConfig(USART1, USART_IT_RXNE, DISABLE);
        USART_ITConfig(USART1, USART_IT_TXE, DISABLE);
        TX[tempTX_Head]= data;
        /* Advance buffer head. */
        TX_Head = (tempTX_Head + 1) % (UART_BUFSIZE-0);
        USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
        USART_ITConfig(USART1, USART_IT_TXE, ENABLE);
    }
    return isFree;
}

char Usart_DataAvailable()
{
    uint16_t tempHead = RX_Head;
    uint16_t tempTail = RX_Tail;
    /* There are data left in the buffer unless Head and Tail are equal. */
    return (tempHead != tempTail);
}

uint8_t Usart_Getch()
{
    uint8_t ans;


    USART_ITConfig(USART1, USART_IT_RXNE, DISABLE);
    USART_ITConfig(USART1, USART_IT_TXE, DISABLE);
    ans = (RX[RX_Tail]);
    RX_Tail = (RX_Tail + 1) % (UART_BUFSIZE-0);
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    USART_ITConfig(USART1, USART_IT_TXE, ENABLE);

    return ans;
}

// �жϳ���
extern "C" void USART1_IRQHandler(void)
{
    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        uint16_t tempRX_Head = (RX_Head + 1) % (UART_BUFSIZE-0);
        
        uint16_t tempRX_Tail = RX_Tail;
        uint8_t data = USART_ReceiveData(USART1);
        
        if (tempRX_Head == tempRX_Tail) {
            USART_ITConfig(USART1, USART_IT_RXNE, DISABLE);
        }else{
            RX[RX_Head] = data;
            RX_Head = tempRX_Head;
        }
    }
    
    if(USART_GetITStatus(USART1, USART_IT_TXE) != RESET)
    {
        uint16_t tempTX_Tail = TX_Tail;
        if (TX_Head == tempTX_Tail)
        {
            USART_ITConfig(USART1, USART_IT_TXE, DISABLE);
        }
        else
        {
            uint8_t data = TX[TX_Tail];
            USART_SendData(USART1, (unsigned char) data);
            TX_Tail = (TX_Tail + 1) % (UART_BUFSIZE-0);
        }
    }
}

