#include "includes.h"
#include "struct_all.h"
#include "std_msgs/String.h"
#include "geometry_msgs/Twist.h"
#include "Tasks.h"
#include "Maths.h"
#include "Filter.h"

void msgCallBack(const std_msgs::String& msg);
std_msgs::String msg1;

//-------------ROS����----------------
ros::NodeHandle nh;
ros::Subscriber<std_msgs::String> sub("stm_subscribe", msgCallBack);
ros::Publisher pub("stm_publish",&msg1);
int i=0;

void msgCallBack(const std_msgs::String& msg)
{	
	char hello[150];
  sprintf(hello, "\n\t   PITCH\tROLL\tYAW\nACC:\t   %-13d%-8d%-5d\nGYRO:\t   %-13d%-8d%-5d\nFILTER_ACC:%-13d%-8d%-5d",(int)nrf[i+1],(int)nrf[i],(int)nrf[i+2],(int)nrf[i+4]/8,(int)nrf[i+3]/8,(int)nrf[i+5]/8,(int)nrf[i+7]/3,(int)nrf[i+6]/3,(int)nrf[i+8]/3);  
  msg1.data = hello;
  pub.publish(&msg1);
}

int main(void)
{   
    // ��ʼ���׶�
    System_Init();
	
		nh.initNode();
	  nh.advertise(pub);
    nh.subscribe(sub);
		//Ӳ����ʼ��
	  BSP_Init();
	  while(1)
		{
			if(Count_2ms>=1)
			{
				Count_2ms = 0;
				Task_500HZ();
			}
			if(Count_10ms>=5)
			{
				Count_10ms = 0;
				Task_100HZ();
			}
			if(Count_40ms>=20)
			{
				Count_40ms = 0;
				Task_25HZ();
			}
			if(Count_250ms>=125)
			{
				Count_250ms = 0;
				Task_4HZ();
			}
      nh.spinOnce();
      delay_ms(10);
		}
}

