#ifndef __INCLUDES_H__
#define __INCLUDES_H__

// ��׼�ļ�
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// f1�ļ�
#include "stm32f10x.h"

// ϵͳ�ļ�
//#include "system.h"
#include "usart.h"
#include "Stm32Hardware.h"
#include "ros.h"

#endif
