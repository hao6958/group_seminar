#ifndef __STM32HARDWARE_H__
#define __STM32HARDWARE_H__

#include "includes.h"
#include <stdint.h>
#include "Tasks.h"

class Stm32Hardware
{
	public:
		Stm32Hardware(){};
		void init(void)
        {
            System_Init();
            delay_ms(1000);
            Usart_Configuration();
        }
		int read(void)
        {
            if(Usart_DataAvailable())
            {
                return Usart_Getch();
            }
            else
            {
                return -1;
            }
        }
		void write(uint8_t* data, int length)
        {
            for(int i=0;i<length;i++)
            {
                Usart_Send(data[i]);
            }
        }
		unsigned long time(void){return System_GetTime();}
};


#endif
