#include "imu.h"
#include "mpu6050.h"
#include "led.h"
#include "includes.h"
#include "fast_math.h"

/*               ����������                  */
static float q0=1,q1=0,q2=0,q3=0;
static float ImuKi = 0.001f,ImuKp = 0.2f;
static float Imu_Oular[3];

/*               ��̬������                  */
static void Imu_Update(float* gyro, float* accl, float dt);
static void Imu_Q2O(void);

/*               ����������                  */
// IMU��ʼ��
void Imu_Init(void)
{    
    delay_ms(1000);
    
    if(Mpu6050_Init())
    {
        uint8_t i = 2;
        while(i--)
        {
            Led_Green_ON();
            delay_ms(200);   
            Led_Green_OFF();
            delay_ms(200);
        }
    }
}

// IMU����������100hz
void Imu_Attiude(void)
{
    static uint32_t _local_time = 0;
    
    if(_local_time == 0)
    {
        _local_time = runtime;
        return;
    }    
    if(runtime - _local_time < 2) return;    
    
    float dt = (runtime - _local_time)*0.001f;
    
    _local_time = runtime;
    
    Mpu6050_Read();
}

// IMU����
static void Imu_Update(float* gyro, float* accl, float dt)
{
    static volatile float integralFBx = 0.0f,  integralFBy = 0.0f, integralFBz = 0.0f;
    
	float gx = gyro[0];
	float gy = gyro[1];
	float gz = gyro[2];

	float ax = -accl[0];
	float ay = -accl[1];
	float az = -accl[2];

	float recipNorm;
	float halfvx, halfvy, halfvz;
	float halfex, halfey, halfez;

	// Normalise accelerometer measurement
	recipNorm = fast_sqrt(ax * ax + ay * ay + az * az);
	ax /= recipNorm;
	ay /= recipNorm;
	az /= recipNorm;

	// Estimated direction of gravity and vector perpendicular to magnetic flux
	halfvx = 2*(q1 * q3 - q0 * q2);
	halfvy = 2*(q0 * q1 + q2 * q3);
	halfvz = q0 * q0 - q1 * q1 - q2 * q2 + q3 * q3;

	// Error is sum of cross product betw   een estimated and measured direction of gravity
	halfex = (ay * halfvz - az * halfvy);
	halfey = (az * halfvx - ax * halfvz);
	halfez = (ax * halfvy - ay * halfvx);

	// Compute and apply integral feedback if enabled		
	integralFBx += ImuKi * halfex ;	// integral error scaled by Ki
	integralFBy += ImuKi * halfey;
	integralFBz += ImuKi * halfez;
	
	// Apply proportional feedback
	gx += ImuKp * halfex + integralFBx;
	gy += ImuKp * halfey + integralFBy;
	gz += ImuKp * halfez + integralFBz;
	
	float qa = q0;
    float qb = q1;
    float qc = q2;
    
    q0 = q0 + (-qb*gx - qc*gy - q3*gz)*dt/2;
	q1 = q1 + ( qa*gx + qc*gz - q3*gy)*dt/2;
	q2 = q2 + ( qa*gy - qb*gz + q3*gx)*dt/2;
	q3 = q3 + ( qa*gz + qb*gy - qc*gx)*dt/2;
	
	// Normalise quaternion
	recipNorm = fast_sqrt(q0 * q0 + q1 * q1 + q2 * q2 + q3 * q3);
	q0 /= recipNorm;
	q1 /= recipNorm;
	q2 /= recipNorm;
	q3 /= recipNorm;
}

//  ��Ԫ��תŷ����
static void Imu_Q2O(void)      
{		
	float q0q1 = q0 * q1;
	float q0q2 = q0 * q2;
	float q0q3 = q0 * q3;
	float q1q1 = q1 * q1;
	float q1q2 = q1 * q2;
	float q1q3 = q1 * q3;
	float q2q2 = q2 * q2;
	float q2q3 = q2 * q3;	
	float q3q3 = q3 * q3;

    Imu_Oular[0] = asinf(2*q2q3 + 2*q0q1) * 57.3f;
	Imu_Oular[1] = fast_atan2(q0q2 - q1q3, 0.5f - q1q1 - q2q2) * 57.3f;
	Imu_Oular[2] = fast_atan2(q0q3 - q1q2, 0.5f - q1q1 - q3q3) * 57.3f;
}

// IMU������ŷ����
float* Imu_GetOular(void)
{
    return Imu_Oular;
}
